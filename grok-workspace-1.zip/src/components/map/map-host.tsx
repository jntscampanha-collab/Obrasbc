import { useEffect, useRef } from "react";

const enginePromise =
  typeof window === "undefined" ? null : import("./map-engine");

export function MapHost() {
  const mapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const el = mapRef.current;
    const canvas = canvasRef.current;
    if (!el) return;
    let cleanup: (() => void) | undefined;
    let cancelled = false;
    void (enginePromise ?? import("./map-engine")).then((mod) => {
      if (cancelled || !el) return;
      cleanup = mod.mountMap(el, canvas);
    });
    return () => {
      cancelled = true;
      cleanup?.();
    };
  }, []);

  return (
    <div className="absolute inset-0 bg-ocean">
      <div ref={mapRef} className="absolute inset-0" />
      <canvas ref={canvasRef} className="pointer-events-none absolute inset-0 z-[450]" />
    </div>
  );
}
