import { MapPinned, PenLine, Play } from "lucide-react";
import { Button } from "@/components/ui/button";
import { TOTAL_SQM, TOTAL_STREETS } from "@/data/streets";
import { formatSqm } from "@/lib/geo";
import { useTourStore } from "@/store/tour-store";

export function IntroCover() {
  const play = useTourStore((s) => s.play);
  const skipToExplore = useTourStore((s) => s.skipToExplore);

  return (
    <div className="pointer-events-none absolute inset-0 z-[700] flex items-end md:items-center">
      <div className="pointer-events-auto m-3 w-[min(100%-1.5rem,28rem)] rounded-xl bg-paper-elevated/95 p-5 shadow-card ring-1 ring-line md:m-8 md:p-7">
        <p className="text-xs font-medium tracking-[0.18em] text-marker-deep uppercase">
          Balneário Camboriú
        </p>
        <h1 className="font-display mt-3 text-4xl leading-tight tracking-tight text-ink italic md:text-5xl">
          O Mapa do Trabalho
        </h1>
        <p className="mt-3 max-w-sm text-sm leading-relaxed text-ink-soft">
          A canetinha risca, em tempo real, as ruas que já ganharam asfalto novo.
          Assista o traçado ou explore o mapa rua a rua.
        </p>

        <dl className="mt-5 grid grid-cols-2 gap-3">
          <div className="rounded-lg bg-paper px-3 py-3 ring-1 ring-line">
            <dt className="text-xs text-muted">Vias recuperadas</dt>
            <dd className="mt-1 font-display text-2xl tabular-nums text-ink">{TOTAL_STREETS}</dd>
          </div>
          <div className="rounded-lg bg-paper px-3 py-3 ring-1 ring-line">
            <dt className="text-xs text-muted">Asfalto novo</dt>
            <dd className="mt-1 font-display text-2xl tabular-nums text-ink">
              {formatSqm(TOTAL_SQM)}
              <span className="ml-1 text-sm text-muted">m²</span>
            </dd>
          </div>
        </dl>

        <div className="mt-5 flex flex-col gap-2 sm:flex-row">
          <Button variant="marker" size="lg" className="flex-1" onClick={play}>
            <Play className="size-4 fill-current" />
            Assistir o traçado
          </Button>
          <Button variant="outline" size="lg" className="flex-1" onClick={skipToExplore}>
            <MapPinned className="size-4" />
            Explorar
          </Button>
        </div>

        <p className="mt-4 flex items-center gap-2 text-xs text-muted">
          <PenLine className="size-3.5 text-marker" />
          Mapa ilustrativo com ruas reais de BC
        </p>
      </div>
    </div>
  );
}
