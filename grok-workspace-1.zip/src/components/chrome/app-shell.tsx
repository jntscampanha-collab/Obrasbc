import { useEffect } from "react";
import { IntroCover } from "@/components/chrome/intro-cover";
import { TourChrome } from "@/components/chrome/tour-chrome";
import { MapHost } from "@/components/map/map-host";
import { useTourStore } from "@/store/tour-store";

export function AppShell() {
  const phase = useTourStore((s) => s.phase);
  const play = useTourStore((s) => s.play);
  const pause = useTourStore((s) => s.pause);
  const resume = useTourStore((s) => s.resume);
  const skipToExplore = useTourStore((s) => s.skipToExplore);
  const advance = useTourStore((s) => s.advance);

  useEffect(() => {
    if (phase !== "playing") return;
    let raf = 0;
    let last = performance.now();
    const tick = (now: number) => {
      const dt = now - last;
      last = now;
      advance(dt);
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [phase, advance]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      if (e.code === "Space") {
        e.preventDefault();
        const current = useTourStore.getState().phase;
        if (current === "playing") pause();
        else if (current === "paused") resume();
        else if (current === "idle") play();
      }
      if (e.key === "Escape") {
        const current = useTourStore.getState();
        if (current.listOpen) current.setListOpen(false);
        else if (current.phase === "playing" || current.phase === "paused") skipToExplore();
        else current.selectStreet(null);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [pause, resume, play, skipToExplore]);

  return (
    <main className="relative h-dvh overflow-hidden bg-paper">
      <h1 className="sr-only">O Mapa do Trabalho — Balneário Camboriú</h1>
      <MapHost />
      {phase === "idle" ? <IntroCover /> : <TourChrome />}
    </main>
  );
}
