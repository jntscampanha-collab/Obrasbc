import {
  List,
  Pause,
  Play,
  RotateCcw,
  Volume2,
  VolumeX,
  X,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { STREET_BY_ID, STREETS, TOTAL_SQM, TOTAL_STREETS } from "@/data/streets";
import { formatSqm } from "@/lib/geo";
import {
  drawnCount,
  drawnSqm,
  tourProgress01,
  useTourStore,
} from "@/store/tour-store";
import { cn } from "@/lib/utils";

export function TourChrome() {
  const phase = useTourStore((s) => s.phase);
  const caption = useTourStore((s) => s.caption);
  const speaker = useTourStore((s) => s.speaker);
  const elapsed = useTourStore((s) => s.elapsed);
  const progress = useTourStore((s) => s.progress);
  const selectedId = useTourStore((s) => s.selectedId);
  const muted = useTourStore((s) => s.muted);
  const listOpen = useTourStore((s) => s.listOpen);
  const pause = useTourStore((s) => s.pause);
  const resume = useTourStore((s) => s.resume);
  const restart = useTourStore((s) => s.restart);
  const skipToExplore = useTourStore((s) => s.skipToExplore);
  const setMuted = useTourStore((s) => s.setMuted);
  const setListOpen = useTourStore((s) => s.setListOpen);
  const drawStreet = useTourStore((s) => s.drawStreet);
  const selectStreet = useTourStore((s) => s.selectStreet);

  const vias = drawnCount(progress);
  const sqm = drawnSqm(progress);
  const selected = selectedId ? STREET_BY_ID[selectedId] : null;
  const touring = phase === "playing" || phase === "paused";
  const bar = tourProgress01(elapsed);
  const showStreetCard = Boolean(selected) && phase === "explore";

  return (
    <>
      <header className="pointer-events-none absolute inset-x-0 top-0 z-[720] flex items-start justify-between gap-3 p-3 md:p-4">
        <div className="pointer-events-auto rounded-xl bg-paper-elevated/92 px-3 py-2 shadow-card ring-1 ring-line">
          <p className="text-[10px] font-medium tracking-[0.16em] text-marker-deep uppercase">
            Balneário Camboriú
          </p>
          <p className="font-display text-lg italic leading-none text-ink">O Mapa do Trabalho</p>
        </div>
        <div className="pointer-events-auto flex items-center gap-2">
          <div className="hidden rounded-xl bg-paper-elevated/92 px-3 py-2 shadow-card ring-1 ring-line sm:block">
            <p className="text-[10px] text-muted">Vias</p>
            <p className="font-display text-lg tabular-nums leading-none text-ink">
              {vias}
              <span className="text-muted">/{TOTAL_STREETS}</span>
            </p>
          </div>
          <div className="rounded-xl bg-paper-elevated/92 px-3 py-2 shadow-card ring-1 ring-line">
            <p className="text-[10px] text-muted">Asfalto</p>
            <p className="font-display text-lg tabular-nums leading-none text-ink">
              {formatSqm(sqm)}
              <span className="ml-1 text-xs text-muted">m²</span>
            </p>
          </div>
        </div>
      </header>

      <aside className="pointer-events-none absolute top-24 right-4 bottom-4 z-[710] hidden w-80 md:block">
        <div className="pointer-events-auto flex h-full flex-col overflow-hidden rounded-xl bg-paper-elevated/94 shadow-card ring-1 ring-line">
          <div className="px-4 py-3">
            <p className="text-xs font-medium tracking-wide text-muted uppercase">Ruas recuperadas</p>
          </div>
          <Separator />
          <ul className="flex-1 overflow-y-auto px-2 py-2">
            {STREETS.map((street) => {
              const done = (progress[street.id] ?? 0) >= 0.999;
              const active = selectedId === street.id;
              return (
                <li key={street.id}>
                  <button
                    type="button"
                    onClick={() => drawStreet(street.id)}
                    aria-current={active ? "true" : undefined}
                    className={cn(
                      "flex w-full items-center gap-3 rounded-lg px-2 py-2 text-left transition-colors duration-150",
                      active ? "bg-marker-soft" : "hover:bg-paper",
                    )}
                  >
                    <span
                      className={cn(
                        "size-2.5 shrink-0 rounded-full",
                        done ? "bg-marker" : "bg-line",
                      )}
                    />
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-sm text-ink">{street.name}</span>
                      <span className="block truncate text-xs text-muted">{street.bairro}</span>
                    </span>
                    <span className="text-xs tabular-nums text-muted">{street.sqMeters} m²</span>
                  </button>
                </li>
              );
            })}
          </ul>
        </div>
      </aside>

      <div className="pointer-events-none absolute inset-x-0 bottom-0 z-[730] p-3 md:right-96 md:p-4">
        <div className="pointer-events-auto mx-auto max-w-2xl rounded-xl bg-paper-elevated/95 p-3 shadow-card ring-1 ring-line md:p-4">
          {touring ? (
            <div className="mb-3 h-1 overflow-hidden rounded-full bg-paper-deep">
              <div
                className="h-full rounded-full bg-marker transition-[width] duration-150 ease-out"
                style={{ width: `${bar * 100}%` }}
              />
            </div>
          ) : null}

          <div className="flex items-start justify-between gap-3">
            {showStreetCard && selected ? (
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <p className="text-sm font-medium text-ink md:text-base">{selected.name}</p>
                  <Badge variant="marker">{selected.sqMeters} m²</Badge>
                </div>
                <p className="mt-1 text-xs text-muted">{selected.bairro}</p>
                <p className="mt-1 text-sm leading-relaxed text-ink-soft">{selected.blurb}</p>
              </div>
            ) : (
              <div className="min-w-0">
                <p className="text-[10px] font-medium tracking-[0.14em] text-marker-deep uppercase">
                  {speaker}
                </p>
                <p className="mt-1 text-sm leading-relaxed text-ink md:text-base">{caption}</p>
              </div>
            )}
            {showStreetCard ? (
              <button
                type="button"
                className="shrink-0 rounded-md p-1 text-muted hover:bg-paper hover:text-ink"
                onClick={() => selectStreet(null)}
                aria-label="Fechar rua"
              >
                <X className="size-4" />
              </button>
            ) : null}
          </div>

          <div className="mt-3 flex items-center gap-2">
            {phase === "playing" ? (
              <Button size="sm" variant="outline" onClick={pause}>
                <Pause className="size-4" />
                Pausar
              </Button>
            ) : phase === "paused" ? (
              <Button size="sm" variant="marker" onClick={resume}>
                <Play className="size-4 fill-current" />
                Continuar
              </Button>
            ) : (
              <Button size="sm" variant="marker" onClick={restart}>
                <RotateCcw className="size-4" />
                Replay
              </Button>
            )}

            {touring ? (
              <Button size="sm" variant="ghost" onClick={skipToExplore}>
                Pular
              </Button>
            ) : null}

            <Button
              size="icon-sm"
              variant="ghost"
              aria-label={muted ? "Ativar som" : "Silenciar"}
              onClick={() => setMuted(!muted)}
            >
              {muted ? <VolumeX className="size-4" /> : <Volume2 className="size-4" />}
            </Button>

            <div className="ml-auto flex items-center gap-2 md:hidden">
              <span className="text-xs tabular-nums text-muted">
                {vias}/{TOTAL_STREETS} · {formatSqm(sqm)} m²
              </span>
              <Button
                size="icon-sm"
                variant="outline"
                aria-label="Lista de ruas"
                onClick={() => setListOpen(true)}
              >
                <List className="size-4" />
              </Button>
            </div>

            <p className="ml-auto hidden text-xs tabular-nums text-muted md:block">
              {TOTAL_STREETS} vias · {formatSqm(TOTAL_SQM)} m²
            </p>
          </div>
        </div>
      </div>

      {listOpen ? (
        <div className="absolute inset-0 z-[800] bg-ink/40 md:hidden">
          <div className="absolute inset-x-0 bottom-0 max-h-[75dvh] overflow-hidden rounded-t-xl bg-paper-elevated shadow-card">
            <div className="flex items-center justify-between px-4 py-3">
              <p className="text-sm font-medium">Ruas recuperadas</p>
              <Button size="icon-sm" variant="ghost" onClick={() => setListOpen(false)} aria-label="Fechar">
                <X className="size-4" />
              </Button>
            </div>
            <Separator />
            <ul className="max-h-[60dvh] overflow-y-auto px-2 py-2">
              {STREETS.map((street) => {
                const done = (progress[street.id] ?? 0) >= 0.999;
                return (
                  <li key={street.id}>
                    <button
                      type="button"
                      onClick={() => drawStreet(street.id)}
                      className="flex w-full items-center gap-3 rounded-lg px-2 py-2.5 text-left hover:bg-paper"
                    >
                      <span className={cn("size-2.5 rounded-full", done ? "bg-marker" : "bg-line")} />
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-sm">{street.name}</span>
                        <span className="block text-xs text-muted">{street.bairro}</span>
                      </span>
                      <span className="text-xs tabular-nums text-muted">{street.sqMeters} m²</span>
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>
        </div>
      ) : null}
    </>
  );
}
