import { STREETS } from "@/data/streets";

export type Beat =
  | {
      kind: "intro";
      duration: number;
      caption: string;
      speaker: string;
    }
  | {
      kind: "draw";
      duration: number;
      caption: string;
      speaker: string;
      streetIds: string[];
    }
  | {
      kind: "finale";
      duration: number;
      caption: string;
      speaker: string;
    };

export const TOUR: Beat[] = [
  {
    kind: "intro",
    duration: 4200,
    speaker: "Abertura",
    caption:
      "Pessoal, vamos ver quantas ruas já receberam melhorias na nossa cidade? Olha só o nosso mapa...",
  },
  {
    kind: "draw",
    duration: 7800,
    speaker: "Praia Central",
    streetIds: ["atlantica"],
    caption:
      "Para começar, a nossa icônica Avenida Atlântica recebeu atenção total, com mais de 300 metros quadrados recuperados.",
  },
  {
    kind: "draw",
    duration: 7200,
    speaker: "Centro",
    streetIds: ["quinta", "quarta"],
    caption:
      "Seguindo pelo centro, a 5ª e a 4ª Avenida também ganharam cara nova para garantir um trânsito mais fluido.",
  },
  {
    kind: "draw",
    duration: 6800,
    speaker: "Bairros",
    streetIds: ["corupa", "blumenau", "angelina"],
    caption:
      "E o trabalho não para nos bairros: ruas como a Corupá, a Blumenau e tantas outras também foram contempladas.",
  },
  {
    kind: "finale",
    duration: 6200,
    speaker: "Toda a cidade",
    caption:
      "Ao todo, já são mais de 20 vias transformadas, superando 1.400 metros quadrados de asfalto novo. É trabalho em cada canto de BC.",
  },
];

export const TOUR_TOTAL_MS = TOUR.reduce((n, beat) => n + beat.duration, 0);

export const FINALE_IDS = STREETS.filter(
  (s) => !["atlantica", "quinta", "quarta", "corupa", "blumenau", "angelina"].includes(s.id),
).map((s) => s.id);
