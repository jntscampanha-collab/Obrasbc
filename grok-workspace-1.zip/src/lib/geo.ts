import type { LatLngTuple, Street } from "@/data/streets";

export function clamp(n: number, min: number, max: number) {
  return Math.min(max, Math.max(min, n));
}

export function lerp(a: number, b: number, t: number) {
  return a + (b - a) * t;
}

export function easeInOutCubic(t: number) {
  return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
}

export function easeOutCubic(t: number) {
  return 1 - Math.pow(1 - t, 3);
}

function toRad(d: number) {
  return (d * Math.PI) / 180;
}

export function haversine(a: LatLngTuple, b: LatLngTuple) {
  const R = 6371000;
  const dLat = toRad(b[0] - a[0]);
  const dLon = toRad(b[1] - a[1]);
  const lat1 = toRad(a[0]);
  const lat2 = toRad(b[0]);
  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(h)));
}

export function lineLength(line: LatLngTuple[]) {
  let n = 0;
  for (let i = 1; i < line.length; i++) n += haversine(line[i - 1], line[i]);
  return n;
}

export function streetLength(street: Street) {
  return street.lines.reduce((n, line) => n + lineLength(line), 0);
}

export function lerpPoint(a: LatLngTuple, b: LatLngTuple, t: number): LatLngTuple {
  return [lerp(a[0], b[0], t), lerp(a[1], b[1], t)];
}

export function bearingOf(a: LatLngTuple, b: LatLngTuple) {
  const y = Math.sin(toRad(b[1] - a[1])) * Math.cos(toRad(b[0]));
  const x =
    Math.cos(toRad(a[0])) * Math.sin(toRad(b[0])) -
    Math.sin(toRad(a[0])) * Math.cos(toRad(b[0])) * Math.cos(toRad(b[1] - a[1]));
  return (Math.atan2(y, x) * 180) / Math.PI;
}

export function prefixLine(line: LatLngTuple[], t: number): LatLngTuple[] {
  if (line.length === 0) return [];
  if (t <= 0) return [line[0]];
  if (t >= 1) return line;
  const total = lineLength(line);
  if (total === 0) return [line[0]];
  let remain = total * t;
  const out: LatLngTuple[] = [line[0]];
  for (let i = 1; i < line.length; i++) {
    const seg = haversine(line[i - 1], line[i]);
    if (remain <= seg) {
      const f = seg === 0 ? 0 : remain / seg;
      out.push(lerpPoint(line[i - 1], line[i], f));
      return out;
    }
    remain -= seg;
    out.push(line[i]);
  }
  return line;
}

export type DrawnStreet = {
  lines: LatLngTuple[][];
  tip: LatLngTuple | null;
  bearing: number;
};

export function prefixStreet(street: Street, t: number): DrawnStreet {
  const progress = clamp(t, 0, 1);
  if (progress <= 0) {
    const first = street.lines[0]?.[0] ?? null;
    return { lines: [], tip: first, bearing: 0 };
  }
  const total = streetLength(street);
  let remain = total * progress;
  const lines: LatLngTuple[][] = [];
  let tip: LatLngTuple | null = null;
  let bearing = 0;

  for (const line of street.lines) {
    const len = lineLength(line);
    if (len === 0) continue;
    if (remain >= len - 0.01) {
      lines.push(line);
      remain -= len;
      tip = line[line.length - 1] ?? null;
      if (line.length >= 2) {
        bearing = bearingOf(line[line.length - 2], line[line.length - 1]);
      }
    } else {
      const pref = prefixLine(line, remain / len);
      lines.push(pref);
      tip = pref[pref.length - 1] ?? null;
      if (pref.length >= 2) {
        bearing = bearingOf(pref[pref.length - 2], pref[pref.length - 1]);
      }
      remain = 0;
      break;
    }
  }

  return { lines, tip, bearing };
}

export function streetBounds(street: Street): LatLngTuple[] {
  const pts: LatLngTuple[] = [];
  for (const line of street.lines) pts.push(...line);
  return pts;
}

export function allStreetBounds(streets: Street[]): LatLngTuple[] {
  const pts: LatLngTuple[] = [];
  for (const street of streets) pts.push(...streetBounds(street));
  return pts;
}

export function formatSqm(n: number) {
  return new Intl.NumberFormat("pt-BR").format(Math.round(n));
}
