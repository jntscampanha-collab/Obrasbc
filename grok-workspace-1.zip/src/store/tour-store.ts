import { create } from "zustand";
import { STREETS, TOTAL_SQM } from "@/data/streets";
import { clamp, easeInOutCubic, easeOutCubic } from "@/lib/geo";
import { FINALE_IDS, TOUR, TOUR_TOTAL_MS } from "@/lib/tour";
import { playPop, playSwoosh, resumeAudio } from "@/lib/sound";

export type Phase = "idle" | "playing" | "paused" | "explore";

type ProgressMap = Record<string, number>;

type TourState = {
  phase: Phase;
  elapsed: number;
  beatIndex: number;
  beatT: number;
  caption: string;
  speaker: string;
  progress: ProgressMap;
  activeStreetId: string | null;
  selectedId: string | null;
  muted: boolean;
  listOpen: boolean;
  play: () => void;
  pause: () => void;
  resume: () => void;
  restart: () => void;
  skipToExplore: () => void;
  advance: (dt: number) => void;
  selectStreet: (id: string | null) => void;
  drawStreet: (id: string) => void;
  setMuted: (muted: boolean) => void;
  setListOpen: (open: boolean) => void;
};

function emptyProgress(): ProgressMap {
  return Object.fromEntries(STREETS.map((s) => [s.id, 0]));
}

function fullProgress(): ProgressMap {
  return Object.fromEntries(STREETS.map((s) => [s.id, 1]));
}

function applyDraw(ids: string[], t: number, priorComplete: string[]) {
  const next = emptyProgress();
  for (const id of priorComplete) next[id] = 1;
  if (ids.length === 0) return next;
  const scaled = t * ids.length;
  ids.forEach((id, i) => {
    const local = clamp(scaled - i, 0, 1);
    next[id] = Math.max(next[id] ?? 0, easeInOutCubic(local));
  });
  return next;
}

function applyFinale(progress: ProgressMap, t: number) {
  const next = { ...progress };
  const eased = easeOutCubic(t);
  const count = FINALE_IDS.length;
  FINALE_IDS.forEach((id, i) => {
    const stagger = count <= 1 ? 1 : i / (count - 1);
    const local = clamp((eased - stagger * 0.55) / 0.45, 0, 1);
    next[id] = Math.max(next[id] ?? 0, local);
  });
  return next;
}

function captionFor(elapsed: number) {
  let t = elapsed;
  for (const beat of TOUR) {
    if (t <= beat.duration) {
      return { beat, beatT: clamp(t / beat.duration, 0, 1) };
    }
    t -= beat.duration;
  }
  const last = TOUR[TOUR.length - 1];
  return { beat: last, beatT: 1 };
}

let lastSwooshKey = "";
let drawRaf = 0;

export const useTourStore = create<TourState>((set, get) => ({
  phase: "idle",
  elapsed: 0,
  beatIndex: 0,
  beatT: 0,
  caption: TOUR[0].caption,
  speaker: TOUR[0].speaker,
  progress: emptyProgress(),
  activeStreetId: null,
  selectedId: null,
  muted: false,
  listOpen: false,

  play: () => {
    resumeAudio();
    lastSwooshKey = "";
    if (
      typeof window !== "undefined" &&
      window.matchMedia("(prefers-reduced-motion: reduce)").matches
    ) {
      get().skipToExplore();
      return;
    }
    set({
      phase: "playing",
      elapsed: 0,
      beatIndex: 0,
      beatT: 0,
      caption: TOUR[0].caption,
      speaker: TOUR[0].speaker,
      progress: emptyProgress(),
      activeStreetId: null,
      selectedId: null,
    });
  },

  pause: () => {
    if (get().phase === "playing") set({ phase: "paused" });
  },

  resume: () => {
    resumeAudio();
    if (get().phase === "paused") set({ phase: "playing" });
  },

  restart: () => {
    get().play();
  },

  skipToExplore: () => {
    set({
      phase: "explore",
      elapsed: TOUR_TOTAL_MS,
      beatIndex: TOUR.length - 1,
      beatT: 1,
      caption: TOUR[TOUR.length - 1].caption,
      speaker: TOUR[TOUR.length - 1].speaker,
      progress: fullProgress(),
      activeStreetId: null,
    });
  },

  advance: (dt: number) => {
    const state = get();
    if (state.phase !== "playing") return;
    const elapsed = Math.min(TOUR_TOTAL_MS, state.elapsed + dt);
    const { beat, beatT } = captionFor(elapsed);
    const beatIndex = TOUR.indexOf(beat);

    const priorComplete: string[] = [];
    for (let i = 0; i < beatIndex; i++) {
      const prev = TOUR[i];
      if (prev.kind === "draw") priorComplete.push(...prev.streetIds);
    }

    let progress = state.progress;
    let activeStreetId: string | null = null;

    if (beat.kind === "intro") {
      progress = emptyProgress();
    } else if (beat.kind === "draw") {
      progress = applyDraw(beat.streetIds, beatT, priorComplete);
      const which = Math.min(
        beat.streetIds.length - 1,
        Math.floor(beatT * beat.streetIds.length),
      );
      activeStreetId = beat.streetIds[which] ?? beat.streetIds[0] ?? null;
      const swooshKey = `${beatIndex}:${activeStreetId}`;
      if (swooshKey !== lastSwooshKey && activeStreetId) {
        lastSwooshKey = swooshKey;
        if (!get().muted) playSwoosh();
      }
    } else {
      const base = applyDraw([], 1, priorComplete);
      progress = applyFinale(base, beatT);
      for (const id of priorComplete) progress[id] = 1;
      if (beatT > 0.08 && lastSwooshKey !== "finale") {
        lastSwooshKey = "finale";
        if (!get().muted) playPop();
      }
    }

    const done = elapsed >= TOUR_TOTAL_MS;
    set({
      elapsed,
      beatIndex,
      beatT,
      caption: beat.caption,
      speaker: beat.speaker,
      progress,
      activeStreetId: done ? null : activeStreetId,
      phase: done ? "explore" : "playing",
    });
  },

  selectStreet: (id) => {
    set({ selectedId: id, listOpen: false });
  },

  drawStreet: (id) => {
    cancelAnimationFrame(drawRaf);
    const from = get().progress[id] ?? 0;
    if (from >= 1) {
      set({ selectedId: id, phase: "explore", listOpen: false });
      return;
    }
    if (!get().muted) playSwoosh();
    resumeAudio();
    const start = performance.now();
    const duration = 900;
    set({
      selectedId: id,
      activeStreetId: id,
      phase: "explore",
      listOpen: false,
    });
    const tick = (now: number) => {
      const t = clamp((now - start) / duration, 0, 1);
      const v = from + (1 - from) * easeInOutCubic(t);
      set({
        progress: { ...get().progress, [id]: v },
        activeStreetId: t < 1 ? id : null,
      });
      if (t < 1) drawRaf = requestAnimationFrame(tick);
    };
    drawRaf = requestAnimationFrame(tick);
  },

  setMuted: (muted) => set({ muted }),
  setListOpen: (listOpen) => set({ listOpen }),
}));

export function drawnCount(progress: ProgressMap) {
  return STREETS.filter((s) => (progress[s.id] ?? 0) >= 0.999).length;
}

export function drawnSqm(progress: ProgressMap) {
  return STREETS.reduce((n, s) => n + s.sqMeters * (progress[s.id] ?? 0), 0);
}

export function tourProgress01(elapsed: number) {
  return clamp(elapsed / TOUR_TOTAL_MS, 0, 1);
}

export { TOTAL_SQM, TOUR_TOTAL_MS };
