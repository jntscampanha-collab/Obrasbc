import { i as __toESM } from "../_runtime.mjs";
import { a as streetBounds, c as STREET_BY_ID, i as prefixStreet, n as useTourStore, o as CITY_CENTER, r as TOUR, s as STREETS } from "./routes-ByShYCT3.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/map-engine-Bq0d74jY.js
var MARKER = "#0e9f8c";
var MARKER_DEEP = "#0a7a6b";
function padding(map) {
	if (map.getSize().x < 720) return {
		paddingTopLeft: [18, 110],
		paddingBottomRight: [18, 230]
	};
	return {
		paddingTopLeft: [32, 110],
		paddingBottomRight: [360, 36]
	};
}
function toLatLngs(line) {
	return line.map(([lat, lon]) => [lat, lon]);
}
function mountMap(container) {
	let cancelled = false;
	let map = null;
	let canvas = null;
	let raf = 0;
	let unsub = null;
	let hits = null;
	let penMarker = null;
	let lastBeat = -99;
	let lastSelected = "init";
	let lastFollow = 0;
	let hoverId = null;
	const start = async () => {
		const leafletMod = await import("../_libs/leaflet.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
		const L = leafletMod.default ?? leafletMod;
		await Promise.resolve({});
		if (cancelled) return;
		map = L.map(container, {
			center: CITY_CENTER,
			zoom: 14.2,
			zoomControl: false,
			attributionControl: true,
			minZoom: 13,
			maxZoom: 17,
			scrollWheelZoom: false,
			dragging: false,
			doubleClickZoom: false,
			boxZoom: false,
			keyboard: false
		});
		L.tileLayer("https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png", {
			attribution: "&copy; OpenStreetMap &copy; CARTO",
			subdomains: "abcd",
			maxZoom: 19
		}).addTo(map);
		map.attributionControl.setPrefix("");
		L.control.zoom({ position: "bottomleft" }).addTo(map);
		hits = L.layerGroup().addTo(map);
		for (const street of STREETS) for (const line of street.lines) {
			const poly = L.polyline(toLatLngs(line), {
				color: MARKER,
				weight: 18,
				opacity: 0,
				className: "hit-line",
				interactive: true
			}).addTo(hits);
			poly.bindTooltip(street.name, {
				sticky: true,
				opacity: .95
			});
			poly.on("click", () => {
				const phase = useTourStore.getState().phase;
				if (phase === "playing" || phase === "paused") return;
				useTourStore.getState().drawStreet(street.id);
			});
			poly.on("mouseover", () => {
				hoverId = street.id;
			});
			poly.on("mouseout", () => {
				if (hoverId === street.id) hoverId = null;
			});
		}
		const icon = L.divIcon({
			className: "pen-nib",
			html: "<div class=\"pen-nib-inner\"></div>",
			iconSize: [18, 18],
			iconAnchor: [9, 9]
		});
		penMarker = L.marker(CITY_CENTER, {
			icon,
			interactive: false,
			zIndexOffset: 800
		});
		canvas = document.createElement("canvas");
		canvas.className = "pointer-events-none absolute inset-0 z-[450]";
		container.appendChild(canvas);
		const draw = () => {
			if (!map || !canvas) return;
			const ctx = canvas.getContext("2d");
			if (!ctx) return;
			const size = map.getSize();
			const dpr = Math.min(2, window.devicePixelRatio || 1);
			if (canvas.width !== Math.floor(size.x * dpr) || canvas.height !== Math.floor(size.y * dpr)) {
				canvas.width = Math.floor(size.x * dpr);
				canvas.height = Math.floor(size.y * dpr);
				canvas.style.width = `${size.x}px`;
				canvas.style.height = `${size.y}px`;
			}
			ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
			ctx.clearRect(0, 0, size.x, size.y);
			const { progress, activeStreetId, selectedId, phase } = useTourStore.getState();
			let tip = null;
			let bearing = 0;
			const paint = (id, t, emphasized) => {
				const street = STREET_BY_ID[id];
				if (!street || t <= 0) return;
				const drawn = prefixStreet(street, t);
				if (emphasized && drawn.tip) {
					tip = drawn.tip;
					bearing = drawn.bearing;
				}
				for (const line of drawn.lines) {
					if (line.length < 2) continue;
					ctx.beginPath();
					line.forEach((pt, i) => {
						const p = map.latLngToContainerPoint(pt);
						if (i === 0) ctx.moveTo(p.x, p.y);
						else ctx.lineTo(p.x, p.y);
					});
					ctx.lineCap = "round";
					ctx.lineJoin = "round";
					ctx.strokeStyle = emphasized ? "rgba(14, 159, 140, 0.28)" : "rgba(14, 159, 140, 0.18)";
					ctx.lineWidth = emphasized ? 16 : 12;
					ctx.stroke();
					ctx.strokeStyle = emphasized ? MARKER_DEEP : MARKER;
					ctx.globalAlpha = emphasized ? 1 : .92;
					ctx.lineWidth = emphasized ? 6 : 5;
					ctx.stroke();
					ctx.globalAlpha = 1;
				}
			};
			for (const id of Object.keys(progress)) {
				const t = progress[id] ?? 0;
				if (t <= 0 || id === activeStreetId) continue;
				paint(id, t, id === selectedId || id === hoverId);
			}
			if (activeStreetId) paint(activeStreetId, progress[activeStreetId] ?? 0, true);
			if (penMarker) {
				if (tip && (phase === "playing" || Boolean(activeStreetId))) {
					if (!map.hasLayer(penMarker)) penMarker.addTo(map);
					penMarker.setLatLng(tip);
					const inner = penMarker.getElement()?.querySelector(".pen-nib-inner");
					if (inner) inner.style.transform = `rotate(${bearing}deg)`;
				} else if (map.hasLayer(penMarker)) map.removeLayer(penMarker);
			}
		};
		const followCamera = () => {
			if (!map) return;
			const { phase, beatIndex, activeStreetId, selectedId, progress } = useTourStore.getState();
			const pad = padding(map);
			if (phase === "idle") {
				if (lastBeat !== -2) {
					lastBeat = -2;
					map.setView(CITY_CENTER, 14.15, { animate: false });
				}
				map.dragging.enable();
				map.scrollWheelZoom.enable();
				map.doubleClickZoom.enable();
				return;
			}
			if (phase === "playing" && beatIndex !== lastBeat) {
				lastBeat = beatIndex;
				const beat = TOUR[beatIndex];
				if (beat.kind === "intro") map.flyTo(CITY_CENTER, 14.4, { duration: 1.6 });
				else if (beat.kind === "draw") {
					const pts = [];
					for (const id of beat.streetIds) {
						const s = STREET_BY_ID[id];
						if (s) pts.push(...streetBounds(s));
					}
					if (pts.length) map.flyToBounds(pts, {
						...pad,
						maxZoom: 16,
						duration: 1.25
					});
				} else {
					const pts = [];
					for (const s of STREETS) pts.push(...streetBounds(s));
					map.flyToBounds(pts, {
						...pad,
						maxZoom: 14.6,
						duration: 1.6
					});
				}
			}
			if (phase === "playing" && activeStreetId) {
				const now = performance.now();
				if (now - lastFollow > 700) {
					lastFollow = now;
					const street = STREET_BY_ID[activeStreetId];
					if (street) {
						const drawn = prefixStreet(street, progress[activeStreetId] ?? 0);
						if (drawn.tip) {
							const pt = map.latLngToContainerPoint(drawn.tip);
							const size = map.getSize();
							if (pt.x < 80 || pt.y < 120 || pt.x > size.x - (size.x < 720 ? 80 : 360) || pt.y > size.y - (size.x < 720 ? 230 : 80)) map.panTo(drawn.tip, {
								animate: true,
								duration: .55
							});
						}
					}
				}
			}
			if (phase === "explore" && selectedId !== lastSelected) {
				lastSelected = selectedId;
				if (selectedId) {
					const s = STREET_BY_ID[selectedId];
					if (s) map.flyToBounds(streetBounds(s), {
						...pad,
						maxZoom: 16,
						duration: .9
					});
				}
			}
			if (phase === "explore") {
				map.dragging.enable();
				map.scrollWheelZoom.enable();
				map.doubleClickZoom.enable();
			} else if (phase === "playing" || phase === "paused") {
				map.dragging.disable();
				map.scrollWheelZoom.disable();
				map.doubleClickZoom.disable();
			}
		};
		unsub = useTourStore.subscribe(() => {
			followCamera();
		});
		map.on("move zoom viewreset resize", draw);
		const loop = () => {
			draw();
			followCamera();
			raf = requestAnimationFrame(loop);
		};
		raf = requestAnimationFrame(loop);
		map.whenReady(() => {
			map?.invalidateSize();
			followCamera();
			draw();
		});
	};
	start();
	return () => {
		cancelled = true;
		cancelAnimationFrame(raf);
		unsub?.();
		canvas?.remove();
		map?.remove();
		map = null;
	};
}
//#endregion
export { mountMap };
