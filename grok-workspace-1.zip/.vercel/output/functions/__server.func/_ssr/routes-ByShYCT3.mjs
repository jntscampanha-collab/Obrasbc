import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { I as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as create } from "../_libs/zustand.mjs";
import { a as RotateCcw, c as Pause, l as MapPinned, n as VolumeX, o as Play, r as Volume2, s as PenLine, t as X, u as List } from "../_libs/lucide-react.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-ByShYCT3.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var CITY_CENTER = [-26.9924, -48.6347];
var STREETS = [
	{
		id: "atlantica",
		name: "Avenida Atlântica",
		bairro: "Praia Central",
		sqMeters: 320,
		blurb: "A icônica orla recebeu atenção total, com mais de 300 m² recuperados.",
		featured: true,
		group: "featured",
		lines: [[
			[-27.003261, -48.617872],
			[-27.003152, -48.618033],
			[-27.002825, -48.618496],
			[-27.002471, -48.618991],
			[-27.002292, -48.619237],
			[-27.001774, -48.619939],
			[-27.001655, -48.620103],
			[-27.001539, -48.620268],
			[-27.001327, -48.62055],
			[-27.001206, -48.620693],
			[-27.001051, -48.620863],
			[-27.000621, -48.621317],
			[-26.999716, -48.622244],
			[-26.999559, -48.622408],
			[-26.999387, -48.622588],
			[-26.999129, -48.622846],
			[-26.998776, -48.623211],
			[-26.99865, -48.623339],
			[-26.998486, -48.62351],
			[-26.998345, -48.623695],
			[-26.998236, -48.623873],
			[-26.997897, -48.6243],
			[-26.997687, -48.624525],
			[-26.997534, -48.624682],
			[-26.996849, -48.625346],
			[-26.996588, -48.625587],
			[-26.996394, -48.62577],
			[-26.99616, -48.625978],
			[-26.995455, -48.626603],
			[-26.995323, -48.62672],
			[-26.994798, -48.627174],
			[-26.994643, -48.627309],
			[-26.994361, -48.627551],
			[-26.993798, -48.628033],
			[-26.993549, -48.628234],
			[-26.993398, -48.62834],
			[-26.993248, -48.628441],
			[-26.992967, -48.628613],
			[-26.992712, -48.628722],
			[-26.992494, -48.628789],
			[-26.99215, -48.628861],
			[-26.991836, -48.628926],
			[-26.991488, -48.629004],
			[-26.991276, -48.62905],
			[-26.991019, -48.629106],
			[-26.990813, -48.629165],
			[-26.990551, -48.629269],
			[-26.990359, -48.629353],
			[-26.989957, -48.629572],
			[-26.989794, -48.629663],
			[-26.989593, -48.629784],
			[-26.989433, -48.629895],
			[-26.989178, -48.630109],
			[-26.989017, -48.630259],
			[-26.988884, -48.630388],
			[-26.988548, -48.630715],
			[-26.988344, -48.630935],
			[-26.988212, -48.631068],
			[-26.987958, -48.631322],
			[-26.987744, -48.631538],
			[-26.987375, -48.631921]
		]]
	},
	{
		id: "quinta",
		name: "5ª Avenida",
		bairro: "Centro",
		sqMeters: 104,
		blurb: "A Quinta Avenida ganhou cara nova para um trânsito mais fluido.",
		featured: true,
		group: "featured",
		lines: [[
			[-27.004912, -48.636544],
			[-27.004863, -48.636391],
			[-27.004876, -48.636148],
			[-27.004945, -48.635143],
			[-27.004977, -48.634666],
			[-27.005008, -48.634224],
			[-27.005038, -48.633874],
			[-27.005065, -48.633637],
			[-27.005087, -48.633471],
			[-27.00511, -48.633309],
			[-27.005168, -48.632944],
			[-27.005269, -48.632384],
			[-27.005378, -48.63178],
			[-27.005443, -48.631422],
			[-27.005481, -48.631209],
			[-27.005539, -48.630892],
			[-27.005573, -48.630703],
			[-27.005668, -48.630191],
			[-27.005769, -48.629618],
			[-27.005877, -48.629018],
			[-27.005986, -48.628416],
			[-27.006093, -48.627819],
			[-27.006178, -48.627348],
			[-27.00629, -48.626729],
			[-27.006414, -48.626044],
			[-27.006503, -48.625549],
			[-27.006606, -48.62498],
			[-27.006638, -48.6248],
			[-27.006649, -48.624739]
		], [
			[-27.00656, -48.62479],
			[-27.006443, -48.625442],
			[-27.006338, -48.626029],
			[-27.00624, -48.62657],
			[-27.006125, -48.627218],
			[-27.00602, -48.627803],
			[-27.005911, -48.628401],
			[-27.005805, -48.629002],
			[-27.005698, -48.629602],
			[-27.005595, -48.630175],
			[-27.005503, -48.630689],
			[-27.00547, -48.630878],
			[-27.005412, -48.631196],
			[-27.005375, -48.631404],
			[-27.00531, -48.631765],
			[-27.005218, -48.632281],
			[-27.005105, -48.63291],
			[-27.005039, -48.633299],
			[-27.005004, -48.633541],
			[-27.004974, -48.633793],
			[-27.004951, -48.634029],
			[-27.004934, -48.634223],
			[-27.004904, -48.634659],
			[-27.00487, -48.635137],
			[-27.004841, -48.635557],
			[-27.0048, -48.636143],
			[-27.004783, -48.636386],
			[-27.004767, -48.636608]
		]]
	},
	{
		id: "quarta",
		name: "4ª Avenida",
		bairro: "Centro",
		sqMeters: 96,
		blurb: "Mais uma via paralela à praia com recapeamento concluído.",
		featured: false,
		group: "featured",
		lines: [[
			[-26.992711, -48.642061],
			[-26.992915, -48.641964],
			[-26.993292, -48.64179],
			[-26.993616, -48.641635],
			[-26.993852, -48.641524],
			[-26.993988, -48.641455],
			[-26.994125, -48.641377],
			[-26.994257, -48.641295],
			[-26.994486, -48.641129],
			[-26.994857, -48.640851],
			[-26.995259, -48.640551],
			[-26.995583, -48.64031],
			[-26.995708, -48.640217],
			[-26.99611, -48.639914],
			[-26.996336, -48.639745],
			[-26.996468, -48.639647],
			[-26.996965, -48.639276],
			[-26.997342, -48.638993],
			[-26.997483, -48.638888],
			[-26.997661, -48.638755],
			[-26.997868, -48.638599],
			[-26.998202, -48.63835],
			[-26.998602, -48.638052],
			[-26.998956, -48.637787],
			[-26.999088, -48.637687],
			[-26.99921, -48.637596],
			[-26.999587, -48.637315],
			[-27.000017, -48.636994],
			[-27.000346, -48.636747],
			[-27.000665, -48.636483],
			[-27.000825, -48.636324],
			[-27.000979, -48.636114],
			[-27.001064, -48.635923],
			[-27.001131, -48.635686],
			[-27.001154, -48.635369],
			[-27.00115, -48.635183],
			[-27.00114, -48.634851],
			[-27.00113, -48.634637],
			[-27.00112, -48.634423],
			[-27.001098, -48.633958],
			[-27.001108, -48.633719],
			[-27.001186, -48.633481],
			[-27.001266, -48.633344],
			[-27.001589, -48.633046],
			[-27.001755, -48.632786],
			[-27.001801, -48.632609],
			[-27.001883, -48.632275],
			[-27.00195, -48.632001],
			[-27.002061, -48.631591],
			[-27.002128, -48.631385],
			[-27.002219, -48.63114],
			[-27.002274, -48.630952],
			[-27.002338, -48.630594],
			[-27.00239, -48.630269],
			[-27.002412, -48.630137]
		]]
	},
	{
		id: "terceira",
		name: "3ª Avenida",
		bairro: "Centro",
		sqMeters: 82,
		blurb: "Trecho estratégico do centro com asfalto novo.",
		featured: false,
		group: "city",
		lines: [[
			[-27.00109, -48.629797],
			[-27.00094, -48.629928],
			[-27.000442, -48.630392],
			[-27.000311, -48.63054],
			[-27.000155, -48.630671],
			[-26.999747, -48.63103],
			[-26.999379, -48.631353],
			[-26.99904, -48.631651],
			[-26.998869, -48.631802],
			[-26.998656, -48.63199],
			[-26.998384, -48.632229],
			[-26.99805, -48.632522],
			[-26.997871, -48.63268],
			[-26.997721, -48.632813],
			[-26.997392, -48.633103],
			[-26.99697, -48.633476],
			[-26.996639, -48.63377],
			[-26.996523, -48.633872],
			[-26.996402, -48.63398],
			[-26.996094, -48.634252],
			[-26.99571, -48.634591],
			[-26.995396, -48.63487],
			[-26.995223, -48.635022],
			[-26.994901, -48.635307],
			[-26.994551, -48.635616],
			[-26.994162, -48.635961],
			[-26.993754, -48.636321],
			[-26.993389, -48.636645],
			[-26.992923, -48.637056],
			[-26.992599, -48.637343],
			[-26.992258, -48.637644],
			[-26.991943, -48.637909],
			[-26.99156, -48.638213],
			[-26.991081, -48.638579],
			[-26.990831, -48.638765],
			[-26.990396, -48.639069],
			[-26.99009, -48.639285],
			[-26.989803, -48.639436],
			[-26.989605, -48.639464],
			[-26.989188, -48.639502],
			[-26.988723, -48.639544],
			[-26.988294, -48.639584],
			[-26.987994, -48.639611]
		], [
			[-27.002284, -48.624648],
			[-27.002258, -48.624816],
			[-27.00215, -48.625124],
			[-27.002073, -48.62534],
			[-27.001992, -48.625567],
			[-27.001837, -48.626343],
			[-27.001776, -48.626676],
			[-27.001734, -48.626899],
			[-27.001627, -48.627485],
			[-27.001575, -48.627765],
			[-27.001521, -48.628057],
			[-27.001416, -48.62863],
			[-27.001303, -48.629238],
			[-27.001237, -48.629578],
			[-27.0012, -48.629703]
		]]
	},
	{
		id: "brasil",
		name: "Avenida Brasil",
		bairro: "Centro",
		sqMeters: 90,
		blurb: "Eixo de ligação do centro com recapeamento em trechos críticos.",
		featured: false,
		group: "city",
		lines: [[
			[-26.983659, -48.63568],
			[-26.983872, -48.635641],
			[-26.984016, -48.635615],
			[-26.984193, -48.635583],
			[-26.984432, -48.63554],
			[-26.984838, -48.635467],
			[-26.985146, -48.635411],
			[-26.985535, -48.635342],
			[-26.986098, -48.63524],
			[-26.986258, -48.635182],
			[-26.986473, -48.635035],
			[-26.986644, -48.634906],
			[-26.987153, -48.634521],
			[-26.987406, -48.63432],
			[-26.987775, -48.63404],
			[-26.98805, -48.633827],
			[-26.988359, -48.633585],
			[-26.98885, -48.633195],
			[-26.989083, -48.633015],
			[-26.989259, -48.632879],
			[-26.989449, -48.632732],
			[-26.989734, -48.632512],
			[-26.989996, -48.632311],
			[-26.990329, -48.632054],
			[-26.990543, -48.631889],
			[-26.990703, -48.631766],
			[-26.990845, -48.631656],
			[-26.99123, -48.631359],
			[-26.991364, -48.631256],
			[-26.991901, -48.630842],
			[-26.992104, -48.630685],
			[-26.992439, -48.630427],
			[-26.992563, -48.630331],
			[-26.992686, -48.630236],
			[-26.992928, -48.630049],
			[-26.993191, -48.629846],
			[-26.993726, -48.629432],
			[-26.994191, -48.629073],
			[-26.994567, -48.628783],
			[-26.994972, -48.62847],
			[-26.995239, -48.628264],
			[-26.995427, -48.628118],
			[-26.995567, -48.628011],
			[-26.995846, -48.627794],
			[-26.996106, -48.627595],
			[-26.996287, -48.627454],
			[-26.99663, -48.627189],
			[-26.996851, -48.627019],
			[-26.997025, -48.626884],
			[-26.997397, -48.626598],
			[-26.997606, -48.626436],
			[-26.998034, -48.626104],
			[-26.998346, -48.625864],
			[-26.998665, -48.625617],
			[-26.999067, -48.625302],
			[-26.999334, -48.6251],
			[-26.999672, -48.624839],
			[-26.99994, -48.624632],
			[-27.000397, -48.624278],
			[-27.000854, -48.623926],
			[-27.00105, -48.623774],
			[-27.001354, -48.623539],
			[-27.001558, -48.623381],
			[-27.001818, -48.623181],
			[-27.002093, -48.622968],
			[-27.002223, -48.622867],
			[-27.002733, -48.622474],
			[-27.003243, -48.62208],
			[-27.003973, -48.621515],
			[-27.004462, -48.621138],
			[-27.004771, -48.620896],
			[-27.004823, -48.620696],
			[-27.004812, -48.620484],
			[-27.004784, -48.620227],
			[-27.004723, -48.619704],
			[-27.004677, -48.619301]
		]]
	},
	{
		id: "corupa",
		name: "Rua Corupá",
		bairro: "Bairro dos Municípios",
		sqMeters: 48,
		blurb: "No Bairro dos Municípios, a Rua Corupá também foi contemplada.",
		featured: true,
		group: "bairros",
		lines: [[
			[-27.002066, -48.637738],
			[-27.002291, -48.638073],
			[-27.002447, -48.638306],
			[-27.00379, -48.640304],
			[-27.004355, -48.641146],
			[-27.005034, -48.642156],
			[-27.005658, -48.643085],
			[-27.006202, -48.643895],
			[-27.007732, -48.646172],
			[-27.007989, -48.646589],
			[-27.008099, -48.646817],
			[-27.008154, -48.646967]
		]]
	},
	{
		id: "blumenau",
		name: "Rua Blumenau",
		bairro: "Bairro dos Municípios",
		sqMeters: 44,
		blurb: "Mais uma rua do bairro com melhorias de pavimento.",
		featured: false,
		group: "bairros",
		lines: [[
			[-27.002526, -48.636173],
			[-27.003122, -48.637051],
			[-27.004379, -48.638969],
			[-27.00493, -48.639827],
			[-27.005259, -48.640339],
			[-27.006928, -48.642932],
			[-27.007077, -48.643164],
			[-27.007234, -48.643409],
			[-27.008215, -48.644933],
			[-27.008844, -48.645911],
			[-27.009489, -48.646913]
		]]
	},
	{
		id: "angelina",
		name: "Rua Angelina",
		bairro: "Bairro dos Municípios",
		sqMeters: 36,
		blurb: "Pavimentação recuperada no miolo do bairro.",
		featured: false,
		group: "bairros",
		lines: [[
			[-27.008448, -48.641853],
			[-27.008206, -48.641495],
			[-27.007932, -48.641088],
			[-27.007455, -48.640381],
			[-27.00733, -48.640197],
			[-27.006891, -48.639547],
			[-27.00656, -48.639054],
			[-27.006456, -48.638901],
			[-27.006344, -48.638735],
			[-27.005622, -48.63766],
			[-27.005358, -48.637266],
			[-27.005124, -48.636924],
			[-27.005024, -48.636778],
			[-27.004971, -48.6367]
		], [
			[-27.004912, -48.63677],
			[-27.005053, -48.63698],
			[-27.005283, -48.637326],
			[-27.005542, -48.637712],
			[-27.006016, -48.638419],
			[-27.006269, -48.638798],
			[-27.006379, -48.638961],
			[-27.006737, -48.639496],
			[-27.007181, -48.64016],
			[-27.008123, -48.641567],
			[-27.008334, -48.641882],
			[-27.008369, -48.641934]
		]]
	},
	{
		id: "brusque",
		name: "Rua Brusque",
		bairro: "Bairro dos Municípios",
		sqMeters: 40,
		blurb: "Via local com asfalto novo.",
		featured: false,
		group: "bairros",
		lines: [[
			[-27.00903, -48.647049],
			[-27.008891, -48.646808],
			[-27.008554, -48.646246],
			[-27.008458, -48.646099],
			[-27.007704, -48.644938],
			[-27.006735, -48.643446],
			[-27.006548, -48.643158],
			[-27.005469, -48.641496],
			[-27.005268, -48.641188],
			[-27.004227, -48.639584]
		], [[-27.004177, -48.639507], [-27.002364, -48.636724]]]
	},
	{
		id: "biguacu",
		name: "Rua Biguaçu",
		bairro: "Bairro dos Municípios",
		sqMeters: 42,
		blurb: "Melhoria de circulação no Bairro dos Municípios.",
		featured: false,
		group: "bairros",
		lines: [[
			[-27.00989, -48.646669],
			[-27.009547, -48.646124],
			[-27.009312, -48.645751],
			[-27.008853, -48.645024],
			[-27.007686, -48.643172],
			[-27.007536, -48.642935],
			[-27.005177, -48.639318],
			[-27.004653, -48.638515],
			[-27.00456, -48.638372],
			[-27.004296, -48.637968],
			[-27.004199, -48.63782],
			[-27.003615, -48.636924],
			[-27.00292, -48.635859],
			[-27.002712, -48.63554]
		]]
	},
	{
		id: "agrolandia",
		name: "Rua Agrolândia",
		bairro: "Bairro dos Municípios",
		sqMeters: 28,
		blurb: "Trecho residencial recuperado.",
		featured: false,
		group: "bairros",
		lines: [[
			[-27.00931, -48.632145],
			[-27.007237, -48.631686],
			[-27.005523, -48.631306],
			[-27.004051, -48.630979]
		]]
	},
	{
		id: "araquari",
		name: "Rua Araquari",
		bairro: "Bairro dos Municípios",
		sqMeters: 24,
		blurb: "Pavimento renovado em via de bairro.",
		featured: false,
		group: "bairros",
		lines: [[
			[-27.008812, -48.634906],
			[-27.007719, -48.634318],
			[-27.005716, -48.633239],
			[-27.005168, -48.632944],
			[-27.003705, -48.632156]
		]]
	},
	{
		id: "campoere",
		name: "Rua Campo Erê",
		bairro: "Bairro dos Municípios",
		sqMeters: 31,
		blurb: "Mais uma rua contemplada no programa.",
		featured: false,
		group: "bairros",
		lines: [[
			[-27.007313, -48.646533],
			[-27.007277, -48.646346],
			[-27.005842, -48.644206],
			[-27.003577, -48.640826],
			[-27.003281, -48.640384],
			[-27.002014, -48.638493],
			[-27.001936, -48.638377]
		]]
	},
	{
		id: "r1500",
		name: "Rua 1500",
		bairro: "Centro",
		sqMeters: 62,
		blurb: "Via transversal do centro com recapeamento.",
		featured: false,
		group: "grid",
		lines: [[
			[-26.989017, -48.630259],
			[-26.990329, -48.632054],
			[-26.991071, -48.633072],
			[-26.991297, -48.633395],
			[-26.991605, -48.633862],
			[-26.991857, -48.634244],
			[-26.992117, -48.634628],
			[-26.992468, -48.635223],
			[-26.993098, -48.636194],
			[-26.993389, -48.636645],
			[-26.993637, -48.637026],
			[-26.993738, -48.637181],
			[-26.994242, -48.637957],
			[-26.995265, -48.639533],
			[-26.995708, -48.640217],
			[-26.996178, -48.640941],
			[-26.996256, -48.641137],
			[-26.99685, -48.642064],
			[-26.998061, -48.643918],
			[-26.998233, -48.644083],
			[-26.999156, -48.645419]
		]]
	},
	{
		id: "r2000",
		name: "Rua 2000",
		bairro: "Centro",
		sqMeters: 50,
		blurb: "Transversal com asfalto recuperado.",
		featured: false,
		group: "grid",
		lines: [[
			[-27.000123, -48.64237],
			[-26.999212, -48.641002],
			[-26.998786, -48.640346],
			[-26.998292, -48.639583],
			[-26.998144, -48.639422],
			[-26.99797, -48.639241],
			[-26.997661, -48.638755],
			[-26.997098, -48.637891],
			[-26.996698, -48.637279],
			[-26.996584, -48.637104],
			[-26.99572, -48.63578],
			[-26.995545, -48.635511],
			[-26.995223, -48.635022],
			[-26.995036, -48.634732],
			[-26.994489, -48.633893],
			[-26.994041, -48.633207],
			[-26.99381, -48.632853],
			[-26.993674, -48.632669],
			[-26.993548, -48.632511],
			[-26.992104, -48.630685],
			[-26.991416, -48.629793],
			[-26.990917, -48.629132]
		]]
	},
	{
		id: "r2500",
		name: "Rua 2500",
		bairro: "Centro",
		sqMeters: 47,
		blurb: "Melhoria de pista e drenagem.",
		featured: false,
		group: "grid",
		lines: [[
			[-27.001333, -48.637909],
			[-27.000437, -48.636679],
			[-26.999292, -48.634959],
			[-26.998334, -48.63352],
			[-26.99781, -48.632733],
			[-26.997639, -48.632476],
			[-26.997062, -48.631609],
			[-26.994972, -48.62847],
			[-26.994361, -48.627551]
		]]
	},
	{
		id: "r2800",
		name: "Rua 2800",
		bairro: "Centro",
		sqMeters: 38,
		blurb: "Trecho curto com recapeamento pontual.",
		featured: false,
		group: "grid",
		lines: [[
			[-26.995455, -48.626603],
			[-26.995927, -48.627321],
			[-26.996071, -48.627542],
			[-26.997237, -48.629317],
			[-26.99841, -48.631102],
			[-26.998869, -48.631802]
		]]
	},
	{
		id: "r3000",
		name: "Rua 3000",
		bairro: "Centro",
		sqMeters: 52,
		blurb: "Via de acesso recuperada.",
		featured: false,
		group: "grid",
		lines: [[
			[-26.996849, -48.625346],
			[-26.997606, -48.626436],
			[-26.997696, -48.626568],
			[-26.999052, -48.628575],
			[-26.999557, -48.629322],
			[-27.000013, -48.629997],
			[-27.000292, -48.63039],
			[-27.000409, -48.630561],
			[-27.000618, -48.630865],
			[-27.001728, -48.6325],
			[-27.002619, -48.633831]
		]]
	},
	{
		id: "r2550",
		name: "Rua 2550",
		bairro: "Centro",
		sqMeters: 33,
		blurb: "Pavimento novo em transversal do centro.",
		featured: false,
		group: "grid",
		lines: [[
			[-26.995239, -48.628264],
			[-26.997309, -48.631398],
			[-26.99805, -48.632522],
			[-26.998577, -48.63332],
			[-26.999323, -48.63445],
			[-27.000665, -48.636483],
			[-27.001339, -48.637504],
			[-27.00141, -48.637712]
		]]
	},
	{
		id: "alvin",
		name: "Avenida Alvin Bauer",
		bairro: "Barra Norte",
		sqMeters: 70,
		blurb: "Ligação da Barra Norte contemplada no mapa da obra.",
		featured: false,
		group: "city",
		lines: [[
			[-26.985563, -48.63331],
			[-26.985759, -48.633814],
			[-26.985833, -48.63397],
			[-26.986222, -48.634479],
			[-26.98652, -48.634894],
			[-26.986621, -48.635039],
			[-26.987962, -48.637038],
			[-26.989605, -48.639464],
			[-26.990252, -48.640418],
			[-26.99073, -48.64112],
			[-26.990966, -48.641467],
			[-26.991228, -48.641847],
			[-26.991702, -48.642535],
			[-26.993465, -48.645124],
			[-26.993595, -48.645312]
		]]
	},
	{
		id: "estado",
		name: "Avenida do Estado",
		bairro: "Centro",
		sqMeters: 29,
		blurb: "Trecho de ligação regional recuperado.",
		featured: false,
		group: "city",
		lines: [[
			[-26.989201, -48.642165],
			[-26.989086, -48.642001],
			[-26.988548, -48.641221],
			[-26.988412, -48.641023],
			[-26.988303, -48.640866],
			[-26.988179, -48.640686],
			[-26.98766, -48.639933],
			[-26.98759, -48.63985]
		]]
	},
	{
		id: "domhenrique",
		name: "Rua Dom Henrique",
		bairro: "Centro",
		sqMeters: 34,
		blurb: "Rua do centro com melhorias de piso.",
		featured: false,
		group: "bairros",
		lines: [[
			[-27.00432, -48.630529],
			[-27.004585, -48.630586],
			[-27.005433, -48.63077],
			[-27.005609, -48.630804],
			[-27.006264, -48.630948],
			[-27.007208, -48.631157],
			[-27.009245, -48.6316],
			[-27.009402, -48.631635]
		]]
	}
];
var STREET_BY_ID = Object.fromEntries(STREETS.map((s) => [s.id, s]));
var TOTAL_STREETS = STREETS.length;
var TOTAL_SQM = STREETS.reduce((n, s) => n + s.sqMeters, 0);
function clamp(n, min, max) {
	return Math.min(max, Math.max(min, n));
}
function lerp(a, b, t) {
	return a + (b - a) * t;
}
function easeInOutCubic(t) {
	return t < .5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
}
function easeOutCubic(t) {
	return 1 - Math.pow(1 - t, 3);
}
function toRad(d) {
	return d * Math.PI / 180;
}
function haversine(a, b) {
	const R = 6371e3;
	const dLat = toRad(b[0] - a[0]);
	const dLon = toRad(b[1] - a[1]);
	const lat1 = toRad(a[0]);
	const lat2 = toRad(b[0]);
	const h = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLon / 2) ** 2;
	return 2 * R * Math.asin(Math.min(1, Math.sqrt(h)));
}
function lineLength(line) {
	let n = 0;
	for (let i = 1; i < line.length; i++) n += haversine(line[i - 1], line[i]);
	return n;
}
function streetLength(street) {
	return street.lines.reduce((n, line) => n + lineLength(line), 0);
}
function lerpPoint(a, b, t) {
	return [lerp(a[0], b[0], t), lerp(a[1], b[1], t)];
}
function bearingOf(a, b) {
	const y = Math.sin(toRad(b[1] - a[1])) * Math.cos(toRad(b[0]));
	const x = Math.cos(toRad(a[0])) * Math.sin(toRad(b[0])) - Math.sin(toRad(a[0])) * Math.cos(toRad(b[0])) * Math.cos(toRad(b[1] - a[1]));
	return Math.atan2(y, x) * 180 / Math.PI;
}
function prefixLine(line, t) {
	if (line.length === 0) return [];
	if (t <= 0) return [line[0]];
	if (t >= 1) return line;
	const total = lineLength(line);
	if (total === 0) return [line[0]];
	let remain = total * t;
	const out = [line[0]];
	for (let i = 1; i < line.length; i++) {
		const seg = haversine(line[i - 1], line[i]);
		if (remain <= seg) {
			const f = seg === 0 ? 0 : remain / seg;
			out.push(lerpPoint(line[i - 1], line[i], f));
			return out;
		}
		remain -= seg;
		out.push(line[i]);
	}
	return line;
}
function prefixStreet(street, t) {
	const progress = clamp(t, 0, 1);
	if (progress <= 0) return {
		lines: [],
		tip: street.lines[0]?.[0] ?? null,
		bearing: 0
	};
	let remain = streetLength(street) * progress;
	const lines = [];
	let tip = null;
	let bearing = 0;
	for (const line of street.lines) {
		const len = lineLength(line);
		if (len === 0) continue;
		if (remain >= len - .01) {
			lines.push(line);
			remain -= len;
			tip = line[line.length - 1] ?? null;
			if (line.length >= 2) bearing = bearingOf(line[line.length - 2], line[line.length - 1]);
		} else {
			const pref = prefixLine(line, remain / len);
			lines.push(pref);
			tip = pref[pref.length - 1] ?? null;
			if (pref.length >= 2) bearing = bearingOf(pref[pref.length - 2], pref[pref.length - 1]);
			remain = 0;
			break;
		}
	}
	return {
		lines,
		tip,
		bearing
	};
}
function streetBounds(street) {
	const pts = [];
	for (const line of street.lines) pts.push(...line);
	return pts;
}
function formatSqm(n) {
	return new Intl.NumberFormat("pt-BR").format(Math.round(n));
}
var TOUR = [
	{
		kind: "intro",
		duration: 4200,
		speaker: "Abertura",
		caption: "Pessoal, vamos ver quantas ruas já receberam melhorias na nossa cidade? Olha só o nosso mapa..."
	},
	{
		kind: "draw",
		duration: 7800,
		speaker: "Praia Central",
		streetIds: ["atlantica"],
		caption: "Para começar, a nossa icônica Avenida Atlântica recebeu atenção total, com mais de 300 metros quadrados recuperados."
	},
	{
		kind: "draw",
		duration: 7200,
		speaker: "Centro",
		streetIds: ["quinta", "quarta"],
		caption: "Seguindo pelo centro, a 5ª e a 4ª Avenida também ganharam cara nova para garantir um trânsito mais fluido."
	},
	{
		kind: "draw",
		duration: 6800,
		speaker: "Bairros",
		streetIds: [
			"corupa",
			"blumenau",
			"angelina"
		],
		caption: "E o trabalho não para nos bairros: ruas como a Corupá, a Blumenau e tantas outras também foram contempladas."
	},
	{
		kind: "finale",
		duration: 6200,
		speaker: "Toda a cidade",
		caption: "Ao todo, já são mais de 20 vias transformadas, superando 1.400 metros quadrados de asfalto novo. É trabalho em cada canto de BC."
	}
];
var TOUR_TOTAL_MS = TOUR.reduce((n, beat) => n + beat.duration, 0);
var FINALE_IDS = STREETS.filter((s) => ![
	"atlantica",
	"quinta",
	"quarta",
	"corupa",
	"blumenau",
	"angelina"
].includes(s.id)).map((s) => s.id);
var ctx = null;
function getCtx() {
	if (typeof window === "undefined") return null;
	if (!ctx) {
		const Ctor = window.AudioContext || window.webkitAudioContext;
		if (!Ctor) return null;
		ctx = new Ctor();
	}
	return ctx;
}
function resumeAudio() {
	const audio = getCtx();
	if (audio && audio.state === "suspended") audio.resume();
}
function playSwoosh() {
	const audio = getCtx();
	if (!audio) return;
	const now = audio.currentTime;
	const osc = audio.createOscillator();
	const filter = audio.createBiquadFilter();
	const gain = audio.createGain();
	osc.type = "triangle";
	osc.frequency.setValueAtTime(540, now);
	osc.frequency.exponentialRampToValueAtTime(160, now + .22);
	filter.type = "lowpass";
	filter.frequency.setValueAtTime(1400, now);
	filter.frequency.exponentialRampToValueAtTime(420, now + .22);
	gain.gain.setValueAtTime(1e-4, now);
	gain.gain.exponentialRampToValueAtTime(.07, now + .02);
	gain.gain.exponentialRampToValueAtTime(1e-4, now + .26);
	osc.connect(filter);
	filter.connect(gain);
	gain.connect(audio.destination);
	osc.start(now);
	osc.stop(now + .28);
}
function playPop() {
	const audio = getCtx();
	if (!audio) return;
	const now = audio.currentTime;
	const osc = audio.createOscillator();
	const gain = audio.createGain();
	osc.type = "sine";
	osc.frequency.setValueAtTime(380, now);
	osc.frequency.exponentialRampToValueAtTime(220, now + .12);
	gain.gain.setValueAtTime(1e-4, now);
	gain.gain.exponentialRampToValueAtTime(.05, now + .01);
	gain.gain.exponentialRampToValueAtTime(1e-4, now + .16);
	osc.connect(gain);
	gain.connect(audio.destination);
	osc.start(now);
	osc.stop(now + .18);
}
function emptyProgress() {
	return Object.fromEntries(STREETS.map((s) => [s.id, 0]));
}
function fullProgress() {
	return Object.fromEntries(STREETS.map((s) => [s.id, 1]));
}
function applyDraw(ids, t, priorComplete) {
	const next = emptyProgress();
	for (const id of priorComplete) next[id] = 1;
	if (ids.length === 0) return next;
	const scaled = t * ids.length;
	ids.forEach((id, i) => {
		const local = clamp(scaled - i, 0, 1);
		next[id] = Math.max(next[id] ?? 0, easeInOutCubic(local));
	});
	return next;
}
function applyFinale(progress, t) {
	const next = { ...progress };
	const eased = easeOutCubic(t);
	const count = FINALE_IDS.length;
	FINALE_IDS.forEach((id, i) => {
		const stagger = count <= 1 ? 1 : i / (count - 1);
		const local = clamp((eased - stagger * .55) / .45, 0, 1);
		next[id] = Math.max(next[id] ?? 0, local);
	});
	return next;
}
function captionFor(elapsed) {
	let t = elapsed;
	for (const beat of TOUR) {
		if (t <= beat.duration) return {
			beat,
			beatT: clamp(t / beat.duration, 0, 1)
		};
		t -= beat.duration;
	}
	return {
		beat: TOUR[TOUR.length - 1],
		beatT: 1
	};
}
var lastSwooshKey = "";
var drawRaf = 0;
var useTourStore = create((set, get) => ({
	phase: "idle",
	elapsed: 0,
	beatIndex: 0,
	beatT: 0,
	caption: TOUR[0].caption,
	speaker: TOUR[0].speaker,
	progress: emptyProgress(),
	activeStreetId: null,
	selectedId: null,
	muted: false,
	listOpen: false,
	play: () => {
		resumeAudio();
		lastSwooshKey = "";
		if (typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
			get().skipToExplore();
			return;
		}
		set({
			phase: "playing",
			elapsed: 0,
			beatIndex: 0,
			beatT: 0,
			caption: TOUR[0].caption,
			speaker: TOUR[0].speaker,
			progress: emptyProgress(),
			activeStreetId: null,
			selectedId: null
		});
	},
	pause: () => {
		if (get().phase === "playing") set({ phase: "paused" });
	},
	resume: () => {
		resumeAudio();
		if (get().phase === "paused") set({ phase: "playing" });
	},
	restart: () => {
		get().play();
	},
	skipToExplore: () => {
		set({
			phase: "explore",
			elapsed: TOUR_TOTAL_MS,
			beatIndex: TOUR.length - 1,
			beatT: 1,
			caption: TOUR[TOUR.length - 1].caption,
			speaker: TOUR[TOUR.length - 1].speaker,
			progress: fullProgress(),
			activeStreetId: null
		});
	},
	advance: (dt) => {
		const state = get();
		if (state.phase !== "playing") return;
		const elapsed = Math.min(TOUR_TOTAL_MS, state.elapsed + dt);
		const { beat, beatT } = captionFor(elapsed);
		const beatIndex = TOUR.indexOf(beat);
		const priorComplete = [];
		for (let i = 0; i < beatIndex; i++) {
			const prev = TOUR[i];
			if (prev.kind === "draw") priorComplete.push(...prev.streetIds);
		}
		let progress = state.progress;
		let activeStreetId = null;
		if (beat.kind === "intro") progress = emptyProgress();
		else if (beat.kind === "draw") {
			progress = applyDraw(beat.streetIds, beatT, priorComplete);
			const which = Math.min(beat.streetIds.length - 1, Math.floor(beatT * beat.streetIds.length));
			activeStreetId = beat.streetIds[which] ?? beat.streetIds[0] ?? null;
			const swooshKey = `${beatIndex}:${activeStreetId}`;
			if (swooshKey !== lastSwooshKey && activeStreetId) {
				lastSwooshKey = swooshKey;
				if (!get().muted) playSwoosh();
			}
		} else {
			progress = applyFinale(applyDraw([], 1, priorComplete), beatT);
			for (const id of priorComplete) progress[id] = 1;
			if (beatT > .08 && lastSwooshKey !== "finale") {
				lastSwooshKey = "finale";
				if (!get().muted) playPop();
			}
		}
		const done = elapsed >= TOUR_TOTAL_MS;
		set({
			elapsed,
			beatIndex,
			beatT,
			caption: beat.caption,
			speaker: beat.speaker,
			progress,
			activeStreetId: done ? null : activeStreetId,
			phase: done ? "explore" : "playing"
		});
	},
	selectStreet: (id) => {
		set({
			selectedId: id,
			listOpen: false
		});
	},
	drawStreet: (id) => {
		cancelAnimationFrame(drawRaf);
		const from = get().progress[id] ?? 0;
		if (from >= 1) {
			set({
				selectedId: id,
				phase: "explore",
				listOpen: false
			});
			return;
		}
		if (!get().muted) playSwoosh();
		resumeAudio();
		const start = performance.now();
		const duration = 900;
		set({
			selectedId: id,
			activeStreetId: id,
			phase: "explore",
			listOpen: false
		});
		const tick = (now) => {
			const t = clamp((now - start) / duration, 0, 1);
			const v = from + (1 - from) * easeInOutCubic(t);
			set({
				progress: {
					...get().progress,
					[id]: v
				},
				activeStreetId: t < 1 ? id : null
			});
			if (t < 1) drawRaf = requestAnimationFrame(tick);
		};
		drawRaf = requestAnimationFrame(tick);
	},
	setMuted: (muted) => set({ muted }),
	setListOpen: (listOpen) => set({ listOpen })
}));
function drawnCount(progress) {
	return STREETS.filter((s) => (progress[s.id] ?? 0) >= .999).length;
}
function drawnSqm(progress) {
	return STREETS.reduce((n, s) => n + s.sqMeters * (progress[s.id] ?? 0), 0);
}
function tourProgress01(elapsed) {
	return clamp(elapsed / TOUR_TOTAL_MS, 0, 1);
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium transition-[transform,background-color,color,box-shadow,opacity] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-marker/50 focus-visible:ring-offset-2 focus-visible:ring-offset-paper disabled:pointer-events-none disabled:opacity-50 active:not-disabled:scale-[0.96] [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-ink text-paper-elevated shadow-card hover:bg-ink-soft",
			marker: "bg-marker text-paper-elevated shadow-card hover:bg-marker-deep",
			outline: "border border-line bg-paper-elevated text-ink hover:bg-marker-soft hover:border-marker/30",
			ghost: "text-ink hover:bg-paper-deep",
			muted: "bg-paper-deep text-ink-soft hover:bg-line/60"
		},
		size: {
			default: "h-11 rounded-lg px-4 text-sm",
			sm: "h-9 rounded-md px-3 text-sm",
			lg: "h-12 rounded-xl px-5 text-base",
			icon: "size-11 rounded-lg",
			"icon-sm": "size-9 rounded-md"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	});
}
function IntroCover() {
	const play = useTourStore((s) => s.play);
	const skipToExplore = useTourStore((s) => s.skipToExplore);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "pointer-events-none absolute inset-0 z-[700] flex items-end md:items-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pointer-events-auto m-3 w-[min(100%-1.5rem,28rem)] rounded-xl bg-paper-elevated/95 p-5 shadow-card ring-1 ring-line md:m-8 md:p-7",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-[0.18em] text-marker-deep uppercase",
					children: "Balneário Camboriú"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display mt-3 text-4xl leading-tight tracking-tight text-ink italic md:text-5xl",
					children: "O Mapa do Trabalho"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-sm text-sm leading-relaxed text-ink-soft",
					children: "A canetinha risca, em tempo real, as ruas que já ganharam asfalto novo. Assista o traçado ou explore o mapa rua a rua."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "mt-5 grid grid-cols-2 gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg bg-paper px-3 py-3 ring-1 ring-line",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs text-muted",
							children: "Vias recuperadas"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-1 font-display text-2xl tabular-nums text-ink",
							children: TOTAL_STREETS
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg bg-paper px-3 py-3 ring-1 ring-line",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs text-muted",
							children: "Asfalto novo"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
							className: "mt-1 font-display text-2xl tabular-nums text-ink",
							children: [formatSqm(TOTAL_SQM), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-1 text-sm text-muted",
								children: "m²"
							})]
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex flex-col gap-2 sm:flex-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "marker",
						size: "lg",
						className: "flex-1",
						onClick: play,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4 fill-current" }), "Assistir o traçado"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "lg",
						className: "flex-1",
						onClick: skipToExplore,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPinned, { className: "size-4" }), "Explorar"]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 flex items-center gap-2 text-xs text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, { className: "size-3.5 text-marker" }), "Mapa ilustrativo com ruas reais de BC"]
				})
			]
		})
	});
}
var badgeVariants = cva("inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium tracking-wide", {
	variants: { variant: {
		default: "bg-paper-deep text-ink-soft",
		marker: "bg-marker-soft text-marker-deep",
		ink: "bg-ink text-paper-elevated"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
function Separator({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		role: "separator",
		className: cn("h-px w-full bg-line", className),
		...props
	});
}
function TourChrome() {
	const phase = useTourStore((s) => s.phase);
	const caption = useTourStore((s) => s.caption);
	const speaker = useTourStore((s) => s.speaker);
	const elapsed = useTourStore((s) => s.elapsed);
	const progress = useTourStore((s) => s.progress);
	const selectedId = useTourStore((s) => s.selectedId);
	const muted = useTourStore((s) => s.muted);
	const listOpen = useTourStore((s) => s.listOpen);
	const pause = useTourStore((s) => s.pause);
	const resume = useTourStore((s) => s.resume);
	const restart = useTourStore((s) => s.restart);
	const skipToExplore = useTourStore((s) => s.skipToExplore);
	const setMuted = useTourStore((s) => s.setMuted);
	const setListOpen = useTourStore((s) => s.setListOpen);
	const drawStreet = useTourStore((s) => s.drawStreet);
	const selectStreet = useTourStore((s) => s.selectStreet);
	const vias = drawnCount(progress);
	const sqm = drawnSqm(progress);
	const selected = selectedId ? STREET_BY_ID[selectedId] : null;
	const touring = phase === "playing" || phase === "paused";
	const bar = tourProgress01(elapsed);
	const showStreetCard = Boolean(selected) && phase === "explore";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "pointer-events-none absolute inset-x-0 top-0 z-[720] flex items-start justify-between gap-3 p-3 md:p-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-auto rounded-xl bg-paper-elevated/92 px-3 py-2 shadow-card ring-1 ring-line",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[10px] font-medium tracking-[0.16em] text-marker-deep uppercase",
					children: "Balneário Camboriú"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-lg italic leading-none text-ink",
					children: "O Mapa do Trabalho"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-auto flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "hidden rounded-xl bg-paper-elevated/92 px-3 py-2 shadow-card ring-1 ring-line sm:block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[10px] text-muted",
						children: "Vias"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-display text-lg tabular-nums leading-none text-ink",
						children: [vias, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-muted",
							children: ["/", TOTAL_STREETS]
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl bg-paper-elevated/92 px-3 py-2 shadow-card ring-1 ring-line",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[10px] text-muted",
						children: "Asfalto"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-display text-lg tabular-nums leading-none text-ink",
						children: [formatSqm(sqm), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-1 text-xs text-muted",
							children: "m²"
						})]
					})]
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
			className: "pointer-events-none absolute top-24 right-4 bottom-4 z-[710] hidden w-80 md:block",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-auto flex h-full flex-col overflow-hidden rounded-xl bg-paper-elevated/94 shadow-card ring-1 ring-line",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "px-4 py-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium tracking-wide text-muted uppercase",
							children: "Ruas recuperadas"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "flex-1 overflow-y-auto px-2 py-2",
						children: STREETS.map((street) => {
							const done = (progress[street.id] ?? 0) >= .999;
							const active = selectedId === street.id;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => drawStreet(street.id),
								"aria-current": active ? "true" : void 0,
								className: cn("flex w-full items-center gap-3 rounded-lg px-2 py-2 text-left transition-colors duration-150", active ? "bg-marker-soft" : "hover:bg-paper"),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-2.5 shrink-0 rounded-full", done ? "bg-marker" : "bg-line") }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "min-w-0 flex-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block truncate text-sm text-ink",
											children: street.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block truncate text-xs text-muted",
											children: street.bairro
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-xs tabular-nums text-muted",
										children: [street.sqMeters, " m²"]
									})
								]
							}) }, street.id);
						})
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pointer-events-none absolute inset-x-0 bottom-0 z-[730] p-3 md:right-96 md:p-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-auto mx-auto max-w-2xl rounded-xl bg-paper-elevated/95 p-3 shadow-card ring-1 ring-line md:p-4",
				children: [
					touring ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-3 h-1 overflow-hidden rounded-full bg-paper-deep",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full rounded-full bg-marker transition-[width] duration-150 ease-out",
							style: { width: `${bar * 100}%` }
						})
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3",
						children: [showStreetCard && selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-medium text-ink md:text-base",
										children: selected.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
										variant: "marker",
										children: [selected.sqMeters, " m²"]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs text-muted",
									children: selected.bairro
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm leading-relaxed text-ink-soft",
									children: selected.blurb
								})
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] font-medium tracking-[0.14em] text-marker-deep uppercase",
								children: speaker
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm leading-relaxed text-ink md:text-base",
								children: caption
							})]
						}), showStreetCard ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "shrink-0 rounded-md p-1 text-muted hover:bg-paper hover:text-ink",
							onClick: () => selectStreet(null),
							"aria-label": "Fechar rua",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
						}) : null]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex items-center gap-2",
						children: [
							phase === "playing" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								onClick: pause,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-4" }), "Pausar"]
							}) : phase === "paused" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "marker",
								onClick: resume,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4 fill-current" }), "Continuar"]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "marker",
								onClick: restart,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "Replay"]
							}),
							touring ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "ghost",
								onClick: skipToExplore,
								children: "Pular"
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "icon-sm",
								variant: "ghost",
								"aria-label": muted ? "Ativar som" : "Silenciar",
								onClick: () => setMuted(!muted),
								children: muted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "ml-auto flex items-center gap-2 md:hidden",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs tabular-nums text-muted",
									children: [
										vias,
										"/",
										TOTAL_STREETS,
										" · ",
										formatSqm(sqm),
										" m²"
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "icon-sm",
									variant: "outline",
									"aria-label": "Lista de ruas",
									onClick: () => setListOpen(true),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, { className: "size-4" })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "ml-auto hidden text-xs tabular-nums text-muted md:block",
								children: [
									TOTAL_STREETS,
									" vias · ",
									formatSqm(TOTAL_SQM),
									" m²"
								]
							})
						]
					})
				]
			})
		}),
		listOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "absolute inset-0 z-[800] bg-ink/40 md:hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute inset-x-0 bottom-0 max-h-[75dvh] overflow-hidden rounded-t-xl bg-paper-elevated shadow-card",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between px-4 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: "Ruas recuperadas"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon-sm",
							variant: "ghost",
							onClick: () => setListOpen(false),
							"aria-label": "Fechar",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "max-h-[60dvh] overflow-y-auto px-2 py-2",
						children: STREETS.map((street) => {
							const done = (progress[street.id] ?? 0) >= .999;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => drawStreet(street.id),
								className: "flex w-full items-center gap-3 rounded-lg px-2 py-2.5 text-left hover:bg-paper",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-2.5 rounded-full", done ? "bg-marker" : "bg-line") }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "min-w-0 flex-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block truncate text-sm",
											children: street.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block text-xs text-muted",
											children: street.bairro
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-xs tabular-nums text-muted",
										children: [street.sqMeters, " m²"]
									})
								]
							}) }, street.id);
						})
					})
				]
			})
		}) : null
	] });
}
function MapHost() {
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const el = ref.current;
		if (!el) return;
		let cleanup;
		let cancelled = false;
		import("./map-engine-Bq0d74jY.mjs").then((mod) => {
			if (cancelled || !el) return;
			cleanup = mod.mountMap(el);
		});
		return () => {
			cancelled = true;
			cleanup?.();
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "absolute inset-0",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref,
			className: "absolute inset-0"
		})
	});
}
function AppShell() {
	const phase = useTourStore((s) => s.phase);
	const play = useTourStore((s) => s.play);
	const pause = useTourStore((s) => s.pause);
	const resume = useTourStore((s) => s.resume);
	const skipToExplore = useTourStore((s) => s.skipToExplore);
	const advance = useTourStore((s) => s.advance);
	(0, import_react.useEffect)(() => {
		if (phase !== "playing") return;
		let raf = 0;
		let last = performance.now();
		const tick = (now) => {
			const dt = now - last;
			last = now;
			advance(dt);
			raf = requestAnimationFrame(tick);
		};
		raf = requestAnimationFrame(tick);
		return () => cancelAnimationFrame(raf);
	}, [phase, advance]);
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
			if (e.code === "Space") {
				e.preventDefault();
				const current = useTourStore.getState().phase;
				if (current === "playing") pause();
				else if (current === "paused") resume();
				else if (current === "idle") play();
			}
			if (e.key === "Escape") {
				const current = useTourStore.getState();
				if (current.listOpen) current.setListOpen(false);
				else if (current.phase === "playing" || current.phase === "paused") skipToExplore();
				else current.selectStreet(null);
			}
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [
		pause,
		resume,
		play,
		skipToExplore
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative h-dvh overflow-hidden bg-paper",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "sr-only",
				children: "O Mapa do Trabalho — Balneário Camboriú"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapHost, {}),
			phase === "idle" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IntroCover, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TourChrome, {})
		]
	});
}
var routes_exports = /* @__PURE__ */ __exportAll({ component: () => Home });
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {});
}
//#endregion
export { streetBounds as a, STREET_BY_ID as c, prefixStreet as i, useTourStore as n, CITY_CENTER as o, TOUR as r, STREETS as s, routes_exports as t };
